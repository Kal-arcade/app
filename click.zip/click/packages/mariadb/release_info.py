__author__ = 'Georg Richter'
__version__ = '1.1.12'
__version_info__ = (1, 1, 12)
